package com.timeview.screentime

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

@Entity(tableName = "usage_entries")
data class UsageEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appName: String,
    val minutes: Int,
    val date: String,
    val category: String = "Other",
    val notes: String = "",
    val isDemo: Boolean = false
)

@Dao
interface UsageDao {
    @Query("SELECT * FROM usage_entries ORDER BY date DESC, appName COLLATE NOCASE")
    fun observeAll(): Flow<List<UsageEntry>>
    @Insert suspend fun insert(entry: UsageEntry)
    @Update suspend fun update(entry: UsageEntry)
    @Delete suspend fun delete(entry: UsageEntry)
    @Query("DELETE FROM usage_entries WHERE isDemo = 1") suspend fun clearDemo()
    @Query("DELETE FROM usage_entries WHERE isDemo = 0") suspend fun clearUserEntries()
    @Query("DELETE FROM usage_entries") suspend fun clearAll()
    @Query("SELECT COUNT(*) FROM usage_entries WHERE isDemo = 1") suspend fun demoCount(): Int
}

@Database(entities = [UsageEntry::class], version = 1, exportSchema = false)
abstract class TimeViewDatabase : RoomDatabase() {
    abstract fun usageDao(): UsageDao
    companion object {
        @Volatile private var INSTANCE: TimeViewDatabase? = null
        fun get(context: android.content.Context): TimeViewDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context.applicationContext, TimeViewDatabase::class.java, "timeview.db")
                    .build().also { INSTANCE = it }
            }
    }
}

class UsageViewModel(private val dao: UsageDao) : ViewModel() {
    val entries = dao.observeAll()
    suspend fun save(entry: UsageEntry) {
        require(entry.minutes >= 0)
        if (entry.id == 0L) dao.insert(entry) else dao.update(entry)
    }
    suspend fun remove(entry: UsageEntry) = dao.delete(entry)
    suspend fun loadDemo(date: String) {
        if (dao.demoCount() > 0) return
        listOf(
            UsageEntry(appName = "Instagram", minutes = 85, date = date, category = "Social", isDemo = true),
            UsageEntry(appName = "YouTube", minutes = 130, date = date, category = "Entertainment", isDemo = true),
            UsageEntry(appName = "WhatsApp", minutes = 45, date = date, category = "Social", isDemo = true),
            UsageEntry(appName = "Chrome", minutes = 38, date = date, category = "Productivity", isDemo = true),
            UsageEntry(appName = "Spotify", minutes = 44, date = date, category = "Entertainment", isDemo = true)
        ).forEach { dao.insert(it) }
    }
    suspend fun clearDemo() = dao.clearDemo()
    suspend fun clearAll() = dao.clearAll()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: UsageViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    UsageViewModel(TimeViewDatabase.get(applicationContext).usageDao()) as T
            })
            TimeViewApp(vm)
        }
    }
}

private fun duration(minutes: Int): String = "${minutes / 60}h ${minutes % 60}m"
private fun dateString(d: LocalDate) = d.format(DateTimeFormatter.ISO_LOCAL_DATE)

@Composable
fun TimeViewApp(vm: UsageViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val all by vm.entries.collectAsState(initial = emptyList())
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var page by remember { mutableStateOf("Dashboard") }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<UsageEntry?>(null) }
    var theme by remember { mutableStateOf("System") }
    var hideApps by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<UsageEntry?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    val dayEntries = all.filter { it.date == dateString(selectedDate) }
    val total = dayEntries.sumOf { it.minutes }
    val grouped = dayEntries.groupBy { it.appName }.map { (name, rows) ->
        rows.first().copy(id = rows.first().id, appName = name, minutes = rows.sumOf { it.minutes },
            notes = rows.joinToString(" · ") { it.notes }.trim(' ', '·'))
    }.sortedByDescending { it.minutes }
    val dark = theme == "Dark" || (theme == "System" && androidx.compose.foundation.isSystemInDarkTheme())
    val scheme = if (dark) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFB9A7FF),
        secondary = androidx.compose.ui.graphics.Color(0xFF8BCBFF)) else lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF6555B8),
        secondary = androidx.compose.ui.graphics.Color(0xFF526B9A),
        background = androidx.compose.ui.graphics.Color(0xFFF7F6FC),
        surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF)
    )
    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = page == "Dashboard", onClick = { page = "Dashboard" },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Dashboard") })
                    NavigationBarItem(selected = page == "History", onClick = { page = "History" },
                        icon = { Icon(Icons.Default.BarChart, null) }, label = { Text("History") })
                    NavigationBarItem(selected = page == "Settings", onClick = { page = "Settings" },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            },
            floatingActionButton = {
                if (page == "Dashboard" && !showEditor) {
                    FloatingActionButton(onClick = { editing = null; showEditor = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add usage")
                    }
                }
            }
        ) { padding ->
            when {
                showEditor -> EntryEditor(
                    initial = editing, defaultDate = dateString(selectedDate),
                    onCancel = { showEditor = false; editing = null },
                    onSave = { entry ->
                        scope.launch { vm.save(entry) }
                        showEditor = false; editing = null
                    }
                )
                page == "Dashboard" -> Dashboard(
                    selectedDate = selectedDate, onDate = { selectedDate = it },
                    entries = grouped, total = total, hideApps = hideApps,
                    onEdit = { entry -> editing = entry; showEditor = true },
                    onDelete = { confirmDelete = it },
                    onShare = {
                        val lines = buildString {
                            append("TimeView · ${selectedDate}\nManual Demo Data\nTotal: ${duration(total)}\n")
                            if (!hideApps) grouped.forEach { append("${it.appName}: ${duration(it.minutes)}\n") }
                        }
                        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, lines)
                        }, "Share dashboard"))
                    },
                    onLoadDemo = { scope.launch { vm.loadDemo(dateString(selectedDate)) } }
                )
                page == "History" -> History(all)
                else -> SettingsPage(
                    theme = theme, onTheme = { theme = it },
                    hideApps = hideApps, onHideApps = { hideApps = it },
                    onClearDemo = { scope.launch { vm.clearDemo() } },
                    onClearAll = { confirmClear = true },
                    onManage = { page = "Dashboard" }
                )
            }
        }
        if (confirmDelete != null) {
            AlertDialog(onDismissRequest = { confirmDelete = null },
                title = { Text("Delete entry?") },
                text = { Text("This removes the selected saved entry. This action cannot be undone.") },
                confirmButton = { TextButton(onClick = {
                    confirmDelete?.let { e -> scope.launch {
                        // Delete the selected underlying row, not a synthetic grouped total.
                        all.firstOrNull { it.appName == e.appName && it.date == dateString(selectedDate) }?.let { vm.remove(it) }
                    } }
                    confirmDelete = null
                }) { Text("Delete") } },
                dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } })
        }
        if (confirmClear) {
            AlertDialog(onDismissRequest = { confirmClear = false },
                title = { Text("Clear all data?") },
                text = { Text("All manual and demo entries stored on this phone will be deleted.") },
                confirmButton = { TextButton(onClick = { scope.launch { vm.clearAll() }; confirmClear = false }) { Text("Clear all") } },
                dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } })
        }
    }
}

@Composable
private fun Dashboard(
    selectedDate: LocalDate, onDate: (LocalDate) -> Unit, entries: List<UsageEntry>, total: Int,
    hideApps: Boolean, onEdit: (UsageEntry) -> Unit, onDelete: (UsageEntry) -> Unit,
    onShare: () -> Unit, onLoadDemo: () -> Unit
) {
    val isToday = selectedDate == LocalDate.now()
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 20.dp, bottom = 100.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Screen time", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Manual Demo Data", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                }
                IconButton(onClick = onShare) { Icon(Icons.Default.Share, "Share dashboard") }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = isToday, onClick = { onDate(LocalDate.now()) }, label = { Text("Today") })
                FilterChip(selected = selectedDate == LocalDate.now().minusDays(1), onClick = { onDate(LocalDate.now().minusDays(1)) }, label = { Text("Yesterday") })
                var dateText by remember(selectedDate) { mutableStateOf(dateString(selectedDate)) }
                OutlinedTextField(value = dateText, onValueChange = { dateText = it }, label = { Text("YYYY-MM-DD") },
                    modifier = Modifier.weight(1f), singleLine = true)
                TextButton(onClick = { runCatching { onDate(LocalDate.parse(dateText)) } }) { Text("Go") }
            }
            Spacer(Modifier.height(12.dp))
            Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(210.dp)) {
                        Canvas(Modifier.fillMaxSize()) {
                            drawArc(color = MaterialTheme.colorScheme.primary.copy(alpha = .13f), startAngle = -90f,
                                sweepAngle = 360f, useCenter = false, style = Stroke(width = 20.dp.toPx(), cap = StrokeCap.Round))
                            if (total > 0) drawArc(color = MaterialTheme.colorScheme.primary, startAngle = -90f,
                                sweepAngle = 360f, useCenter = false, style = Stroke(width = 20.dp.toPx(), cap = StrokeCap.Round))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(duration(total), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            Text("total entered", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text("${entries.size} apps entered", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(selectedDate.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy")), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Your apps", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onLoadDemo) { Text("Load demo") }
            }
            if (entries.isEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp)) {
                        Text("No entries for this date yet.")
                        Text("Add usage or load clearly labelled sample data.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        if (!hideApps) items(entries, key = { "${it.appName}_${it.date}" }) { entry ->
            val pct = if (total == 0) 0 else (entry.minutes * 100f / total).roundToInt()
            Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape), contentAlignment = Alignment.Center) {
                            Text(entry.appName.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.appName, fontWeight = FontWeight.SemiBold)
                            Text("${entry.category} · $pct%", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(duration(entry.minutes), fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { if (total == 0) 0f else entry.minutes.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = { onEdit(entry) }) { Text("Edit") }
                        TextButton(onClick = { onDelete(entry) }) { Text("Delete") }
                    }
                }
            }
        }
        item { Text("All values are entered by the user; they are not measured device usage.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun EntryEditor(initial: UsageEntry?, defaultDate: String, onCancel: () -> Unit, onSave: (UsageEntry) -> Unit) {
    var name by remember { mutableStateOf(initial?.appName ?: "") }
    var hours by remember { mutableStateOf(((initial?.minutes ?: 0) / 60).toString()) }
    var mins by remember { mutableStateOf(((initial?.minutes ?: 0) % 60).toString()) }
    var date by remember { mutableStateOf(initial?.date ?: defaultDate) }
    var category by remember { mutableStateOf(initial?.category ?: "Other") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf("") }
    val cats = listOf("Social", "Entertainment", "Productivity", "Gaming", "Education", "Other")
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(if (initial == null) "Add usage" else "Edit usage", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(name, { name = it }, label = { Text("App name *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        Text("Duration", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(hours, { hours = it.filter(Char::isDigit).take(3) }, label = { Text("Hours") },
                modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(mins, { mins = it.filter(Char::isDigit).take(2) }, label = { Text("Minutes (0–59)") },
                modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        Text("Category", style = MaterialTheme.typography.titleMedium)
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(category, {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text("Category") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                cats.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false }) }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(notes, { notes = it }, label = { Text("Optional notes") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(onClick = {
                val h = hours.toIntOrNull()
                val m = mins.toIntOrNull()
                val parsedDate = runCatching { LocalDate.parse(date); true }.getOrDefault(false)
                if (name.isBlank()) error = "Enter an app name."
                else if (h == null || m == null || h < 0 || m !in 0..59 || h > 999) error = "Enter valid hours and minutes (minutes must be 0–59)."
                else if (!parsedDate) error = "Enter a valid date in YYYY-MM-DD format."
                else {
                    val total = h * 60 + m
                    if (total > 24 * 60) error = "This entry exceeds 24 hours. Please correct it."
                    else onSave(UsageEntry(id = initial?.id ?: 0, appName = name.trim(), minutes = total,
                        date = date, category = category, notes = notes.trim(), isDemo = initial?.isDemo ?: false))
                }
            }, modifier = Modifier.weight(1f)) { Text("Save") }
        }
    }
}

@Composable
private fun History(all: List<UsageEntry>) {
    val today = LocalDate.now()
    val days = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val totals = days.map { d -> all.filter { it.date == dateString(d) }.sumOf { it.minutes } }
    val max = (totals.maxOrNull() ?: 0).coerceAtLeast(1)
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("History", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Last 7 days · manual entries only", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth().height(220.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
            days.forEachIndexed { i, day ->
                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Text(if (totals[i] == 0) "—" else "${totals[i] / 60}h", style = MaterialTheme.typography.labelSmall)
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                        Box(Modifier.fillMaxWidth(.72f).fillMaxHeight((totals[i].toFloat() / max).coerceAtLeast(if (totals[i] > 0) .04f else 0f))
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)))
                    }
                    Text(day.format(DateTimeFormatter.ofPattern("EE")), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        days.reversed().forEach { d ->
            val mins = all.filter { it.date == dateString(d) }.sumOf { it.minutes }
            ListItem(headlineContent = { Text(d.format(DateTimeFormatter.ofPattern("EEE, d MMM"))) },
                supportingContent = { Text("Manual Demo Data") }, trailingContent = { Text(duration(mins), fontWeight = FontWeight.SemiBold) })
        }
    }
}

@Composable
private fun SettingsPage(theme: String, onTheme: (String) -> Unit, hideApps: Boolean, onHideApps: (Boolean) -> Unit,
                         onClearDemo: () -> Unit, onClearAll: () -> Unit, onManage: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Appearance", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("System", "Light", "Dark").forEach { value ->
                FilterChip(selected = theme == value, onClick = { onTheme(value) }, label = { Text(value) })
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 12.dp))
        ListItem(headlineContent = { Text("Manage entries") }, supportingContent = { Text("Edit or delete saved records from Dashboard") },
            modifier = Modifier.clickable { onManage() })
        ListItem(headlineContent = { Text("Share preference") }, supportingContent = { Text("Hide app rows in the shared summary") },
            trailingContent = { Switch(checked = hideApps, onCheckedChange = onHideApps) })
        ListItem(headlineContent = { Text("Demo mode") }, supportingContent = { Text("Clear illustrative sample records") },
            trailingContent = { TextButton(onClick = onClearDemo) { Text("Clear demo") } })
        HorizontalDivider(Modifier.padding(vertical = 12.dp))
        Button(onClick = onClearAll, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
            Icon(Icons.Default.Delete, null); Spacer(Modifier.width(8.dp)); Text("Clear all data")
        }
        Spacer(Modifier.height(20.dp))
        Text("About TimeView", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text("Version 1.0", style = MaterialTheme.typography.bodySmall)
        Text("TimeView stores entries locally on this phone. It does not monitor device activity or collect app-usage telemetry. All displayed values are manually entered or clearly labelled sample data.",
            style = MaterialTheme.typography.bodyMedium)
    }
}
