# TimeView — Screen Time Dashboard

TimeView is a native Android (Kotlin + Jetpack Compose) **manual-entry** screen-time dashboard. It does not read actual device usage and does not request Usage Access, Accessibility, or screen-recording permissions.

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35 (or let Android Studio install it)
- Internet for the first Gradle dependency sync

## Open and build
1. Extract this folder.
2. Open the `TimeView` folder in Android Studio.
3. Allow Gradle sync and install any requested SDK components.
4. Run the `app` configuration on an emulator or Android phone.
5. Debug APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. It is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Release APK: **Build → Generate Signed Bundle / APK → APK**. Create a keystore in the wizard and store it safely. Never commit or share the keystore/password. The signed output is usually under `app/release/`.

## Install on Android
Transfer the debug or signed release APK to the phone. Open it in Files, allow “Install unknown apps” for the app used to open it if Android asks, then install. Only install APKs you built or otherwise trust. If Android reports a signature conflict, uninstall an older build signed with a different key first (this can remove that app's local data).

## Included in this starter project
- Dashboard with date selection (Today / Yesterday / custom date field), total duration, app rows, percentages and progress indicators.
- Add, edit and delete manually entered entries.
- Local Room database persistence.
- Demo data toggle that is kept separate from user-entered entries.
- History view with a simple seven-day chart.
- Light / dark / system theme setting.
- Share a dashboard summary through Android's native share sheet.
- Clear-data confirmation and explicit “Manual Demo Data” labeling.

## Important limitations
- This environment did not have Android SDK or Gradle installed, so an APK could not be compiled or device-tested here. Open in Android Studio to build it.
- Sharing currently sends a text summary using Android Sharesheet; image export/preview is a follow-up implementation item.
- The initial version is a functional learning starter, not a Play Store release. Test on your own device and review dependencies before distribution.
